<?php

return array(
    array(
        'name'  => 'appkey',
        'title' => '百度地图秘钥',
        'type'  => 'text',
        'value' => '',
        'tip'   => '请前往<a href="http://lbsyun.baidu.com/apiconsole/key?application=key" target="_blank">百度地图开放平台</a>获取秘钥',
    ),
);
