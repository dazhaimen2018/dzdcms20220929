<?php

return array(
    array(
        'name'  => 'appid',
        'title' => '熊掌号appid',
        'type'  => 'text',
        'value' => '',
        'tip'   => '熊掌号请前往<a href="https://ziyuan.baidu.com/xzh/home/index" target="_blank">熊掌号平台</a>获取Appid和Token',
    ),
    array(
        'name'  => 'token',
        'title' => '熊掌号token',
        'type'  => 'text',
        'value' => '',
        'tip'   => '',
    ),
    array(
        'name'  => 'site',
        'title' => '百度站长site',
        'type'  => 'text',
        'value' => '',
        'tip'   => '熊掌号请前往<a href="https://ziyuan.baidu.com/xzh/home/index" target="_blank">熊掌号平台</a>获取Appid和Token',
    ),
    array(
        'name'  => 'sitetoken',
        'title' => '百度站长token',
        'type'  => 'text',
        'value' => '',
        'tip'   => '',
    ),
    array(
        'name'    => 'status',
        'title'   => '推送状态',
        'type'    => 'checkbox',
        'options' => array(
            'xiongzhang' => '熊掌号',
            'zhanzhang'  => '百度站长',
        ),
        'tip'     => '',
        'value'   => '',
    ),
);
