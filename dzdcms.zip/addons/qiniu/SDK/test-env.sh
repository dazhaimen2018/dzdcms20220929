export QINIU_ACCESS_KEY=xxx
export QINIU_SECRET_KEY=xxx
export QINIU_TEST_BUCKET=phpsdk
export QINIU_TEST_DOMAIN=phpsdk.qiniudn.com