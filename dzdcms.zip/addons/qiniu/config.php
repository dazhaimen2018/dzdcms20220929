<?php
return [
    0 => [
        'name'  => 'accessKey',
        'title' => '七牛的ak：',
        'type'  => 'text',
        'value' => '',
        'tip'   => '七牛的ak',
    ],
    1 => [
        'name'  => 'secrectKey',
        'title' => '七牛的sk：',
        'type'  => 'text',
        'value' => '',
        'tip'   => '七牛的sk',
    ],
    2 => [
        'name'  => 'bucket',
        'title' => '七牛的空间名称：',
        'type'  => 'text',
        'value' => '',
        'tip'   => '七牛的空间名称',
    ],
    3 => [
        'name'  => 'domain',
        'title' => '七牛的空间对应的域名：',
        'type'  => 'text',
        'value' => '',
        'tip'   => '七牛的空间对应的域名，已http://开头',
    ],
];
